import React from 'react';

export default function Header(){
    return(
        <header>
            <nav id="menu"> 
            <ul className='navbar'> 
                <li><a color="#63cfaf"href="#busina">Business </a></li>
                <li><a href="#sobre">sobre</a></li>
                <li><a href="#fodd">Footer</a></li>
                <li><a href="#integrante">Equipe</a></li>
                
  </ul> 
</nav>
            <img src="capa.jpeg"/>
        </header>
    )
}
