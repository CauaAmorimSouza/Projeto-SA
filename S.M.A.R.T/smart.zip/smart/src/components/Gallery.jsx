import React from 'react';

export default function Gallery(){
    return(
        <section className="Galeria">
            
            <img src="busca.jpg" />
            <img src="comunicacao.jpg"/>
            <img src="lobby.jpg"/>
            <img src="login.jpg"/>
            <img src="postagens.jpg" />
            <img src="usuarios.jpg"/>
        </section>
    )
}
