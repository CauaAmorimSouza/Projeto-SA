import React from 'react';

export default function Busines() {
    return (
        <section className='busines' id='busina'>
            <img className='imgbusines' src="ParceirosChave.png"/>
            <h1>Protótipo</h1>
        </section>
    )
}
