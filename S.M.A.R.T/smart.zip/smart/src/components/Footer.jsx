import React from 'react'

function Footer() {
  return (
    <section id='fodd'>
      <footer>
        <p>© 2024 S.M.A.R.T. System. Todos os direitos reservados.</p>
      </footer>
    </section>
  )
}

export default Footer