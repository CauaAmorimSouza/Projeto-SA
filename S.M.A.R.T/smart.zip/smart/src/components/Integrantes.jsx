import React from 'react'

function Integrantes(){
    return(
    <section id='integrante'>
        <div className='integrantes'>
        <img src="caua.jpeg" />
        <p className='nome'>Cauã Souza</p>
        <img src="ruan.jfif" />
        <p className='nome'>Ruan Tasca Henrique</p>
        <img src="jonas.jpeg" />
        <p className='nome'>Jonas Assunção</p>
        <img src="vi.jpeg"  />
        <p className='nome'>Vitória Mina</p>
        <img src="leo.jpeg"  />
        <p className='nome'>Leonardo Junckes</p>
        <img src="i.jpeg"  />
        <p className='nome'>Isabella Oliveira</p>
        </div>
        <div className='vitor'>
    <img src="vitor.jpeg"  />
    <p className='vitu'>Vitor Schlosser</p>
    </div>
    </section>

    )
}

export default Integrantes